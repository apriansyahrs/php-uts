<?php
session_start();

if (!isset($_SESSION['nama'])) {
    echo "<script language = 'Javascript'>
          confirm('Anda Harus Login Kembali!');
          document.location='auth-login.php';
        </script>";
}

include 'config.php';

$sqlu = mysqli_query($con, "SELECT * FROM tbl_user where username = '$_SESSION[nama]'");
$ru = mysqli_fetch_array($sqlu);
?>
<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="./assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>
      Dashboard - PT. Cahaya Abadi
    </title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link
      rel="icon"
      type="image/x-icon"
      href="./assets/img/favicon/favicon.ico"
    />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link
      rel="stylesheet"
      href="./assets/vendor/fonts/boxicons.css"
    />

    <!-- Core CSS -->
    <link
      rel="stylesheet"
      href="./assets/vendor/css/core.css"
      class="template-customizer-core-css"
    />
    <link
      rel="stylesheet"
      href="./assets/vendor/css/theme-default.css"
      class="template-customizer-theme-css"
    />
    <link rel="stylesheet" href="./assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link
      rel="stylesheet"
      href="./assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css"
    />
    <link
      rel="stylesheet"
      href="./assets/vendor/libs/apex-charts/apex-charts.css"
    />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="./assets/vendor/js/helpers.js"></script>
    <script src="./assets/js/config.js"></script>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
<?php include 'component/aside.php';?>
        <!-- / Menu -->
        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
<?php include 'component/nav.php';?>
          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->
            <div class="container-xxl flex-grow-1 container-p-y">
<?php
if (isset($_GET['page'])) {
    $page = $_GET['page'];

    switch ($page) {

        case 'beranda';
            include "beranda.php";
            break;

        // Tabel Motor
        case 'motor';
            include "./pages/motor/view.php";
            break;
        case 'motor_add';
            include "./pages/motor/add.php";
            break;
        case 'motor_edit';
            include "./pages/motor/edit.php";
            break;
        case 'motor_delete';
            include "./pages/motor/delete.php";
            break;

        // Tabel Beli
        case 'beli';
            include "./pages/beli/view.php";
            break;
        case 'beli_add';
            include "./pages/beli/add.php";
            break;
        case 'beli_edit';
            include "./pages/beli/edit.php";
            break;
        case 'beli_delete';
            include "./pages/beli/delete.php";
            break;

        default:
            echo "Maaf , Halaman Tidak Ditemukan";
    }
} else {
    include "beranda.php";
}

?>
            </div>
            <!-- / Content -->
<?php include 'component/footer.php';?>
            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>
      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="./assets/vendor/libs/jquery/jquery.js"></script>
    <script src="./assets/vendor/libs/popper/popper.js"></script>
    <script src="./assets/vendor/js/bootstrap.js"></script>
    <script src="./assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="./assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="./assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="./assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="./assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
