<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "motor_2019103007";

$con = mysqli_connect($host, $user, $pass, $db);

function rupiah($angka)
{

    $hasil_rupiah = "Rp " . number_format($angka, 2, ',', '.');
    return $hasil_rupiah;

}
