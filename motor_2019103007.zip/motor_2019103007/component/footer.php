<footer class="content-footer footer bg-footer-theme">
  <div class="container-xxl text-center">
    <div class="mb-2">
      ©
      <script>
        document.write(new Date().getFullYear());
      </script>Made with ❤️ by
      <a href="#" target="_blank" class="footer-link fw-bolder">2019103007 - PT. Cahaya Abadi</a>
    </div>
  </div>
</footer>
