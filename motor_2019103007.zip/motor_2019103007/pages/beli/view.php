<div class="d-flex flex-wrap justify-content-between flex-md-row flex-column">
<h4 class="fw-bold py-3 mb-4">
    <span class="text-muted fw-light">Read/</span> Beli
</h4>
<?php
if ($ru['status'] == 'Admin') {
    echo '<div class="blok text-white">
    <a class="btn btn-primary text-white" href="?page=beli_add">Tambah Pembeli</a>
    </div>';
}
?>

</div>


<div class="card">

<div class="table-responsive text-nowrap">
    <table class="table table-striped">
    <thead>
        <tr>
        <th>Tanggal Beli</th>
        <th>Nama Beli</th>
        <th>Kode Motor</th>
        <th>Nama Motor</th>
        <th>Harga</th>
        <th>Jumlah Unit</th>
        <th>Diskon</th>
        <th>Pajak</th>
        <th>Total</th>
<?php
if ($ru['status'] == 'Admin') {
    echo '<th>Actions</th>';
}
?>
        </tr>
    </thead>
    <tbody class="table-border-bottom-0">
    <?php
if ($ru['status'] == 'Admin') {
    $result = mysqli_query($con, "SELECT * FROM tbl_beli");
} else {
    $result = mysqli_query($con, "SELECT * FROM tbl_beli WHERE nm_pembeli = '$ru[nm_user]'");

}

while ($rm = mysqli_fetch_array($result)) {
    ?>
        <tr>
        <td><?=$rm['tgl_pembeli'];?></td>
        <td><?=$rm['nm_pembeli'];?></td>
        <td><span class="badge bg-label-primary me-1"><?=$rm['kd_motor'];?></span></td>
        <td><?=$rm['nm_motor'];?></td>
        <td><?=rupiah($rm['harga']);?></td>
        <td><?=$rm['jumlah'];?></td>
        <td><?=rupiah($rm['diskon']);?></td>
        <td><?=rupiah($rm['pajak']);?></td>
        <td><?=rupiah($rm['total']);?></td>
        <?php
if ($ru['status'] == 'Admin') {
        ?>
        <td>
        <a class="btn btn-warning" href="?page=beli_edit&id_beli=<?=$rm['id_beli']?>"><i class="bx bx-edit-alt me-1"></i></a>
        <a class="btn btn-danger" href="?page=beli_delete&id_beli=<?=$rm['id_beli']?>"><i class="bx bx-trash me-1"></i></a>
        </td>
            <?php
}
    ?>

        </tr>
        <?php
}
?>
    </tbody>
    </table>
</div>
</div>
