
<?php

$id_beli = $_GET['id_beli'];
$sql = mysqli_query($con, "SELECT * FROM tbl_beli WHERE id_beli='$id_beli'");
while ($rb = mysqli_fetch_array($sql)) {
    $nama = $rb['nm_pembeli'];
    $jumlahh = $rb['jumlah'];
    $id = $rb['id_beli'];
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $sqlm = mysqli_query($con, "SELECT * FROM tbl_motor WHERE id_motor = '$_POST[id_motor];'");
    $rm = mysqli_fetch_array($sqlm);
    $kodemotor = $rm['kd_motor'];
    $namamotor = $rm['nm_motor'];
    $hargamotor = $rm['harga'];

    $jumlah = $_POST['jumlah'];

    $diskon = 0.025 * ($jumlah * $hargamotor);
    $pajak = 0.1 * ($jumlah * $hargamotor);
    $total = $diskon - $pajak + ($jumlah * $hargamotor);

    $query = mysqli_query($con, "UPDATE tbl_beli SET tgl_pembeli = '$_POST[tgl_pembeli]',
                                                          nm_pembeli = '$_POST[nm_pembeli]',
                                                          kd_motor = '$kodemotor',
                                                          nm_motor = '$namamotor',
                                                          harga = '$hargamotor',
                                                          jumlah = '$jumlah',
                                                          diskon = '$diskon',
                                                          pajak = '$pajak',
                                                          total = '$total' WHERE id_beli = '$_POST[id_beli]'");

    echo "<script language = 'JavaScript'>
          alert('Data berhasil diupdate');
          document.location='index.php?page=beli';
        </script>";
}

?>

<h4 class="fw-bold py-3 mb-4">
  <span class="text-muted fw-light">Create/</span> Beli
</h4>
<div class="row">
  <div class="col-xl">
    <div class="card mb-4">
      <div class="card-body">
        <form method="post" enctype="multipart/form-data">
          <div class="mb-3">
            <label class="form-label" for="basic-default-fullname"
              >Tanggal Pembeli</label
            >
            <input
              type="date"
              name="tgl_pembeli"
              class="form-control"
            />
            <input
              type="hidden"
              name="id_beli"
              value="<?=$id;?>"
            />
          </div>
          <div class="mb-3">
            <label class="form-label" for="basic-default-company"
              >Nama Pembeli</label
            >
            <input
              type="text"
              name="nm_pembeli"
              class="form-control"
              value="<?=$nama;?>"
            />
          </div>

          <div class="mb-3">
          <label for="exampleFormControlSelect1" class="form-label">Motor</label>
            <select class="form-select" id="exampleFormControlSelect1" aria-label="Default select example" name="id_motor">
              <?php
$result = mysqli_query($con, "SELECT * FROM tbl_motor");
while ($rm = mysqli_fetch_array($result)) {
    ?>
              <option value="<?=$rm['id_motor'];?>"><?=$rm['kd_motor'] . " / " . $rm['nm_motor'] . " / " . rupiah($rm['harga']);?></option>
              <?php
}
?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label" for="basic-default-email">Jumlah</label>
            <div class="input-group input-group-merge">
            <input
              type="text"
              class="form-control phone-mask"
              name="jumlah"
              value="<?=$jumlahh;?>"
            />
            </div>
          </div>

          <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
      </div>
    </div>
  </div>
</div>
