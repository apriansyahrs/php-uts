<div class="d-flex flex-wrap justify-content-between flex-md-row flex-column">
<h4 class="fw-bold py-3 mb-4">
    <span class="text-muted fw-light">Read/</span> Motor
</h4>
<?php
if ($ru['status'] == 'Admin') {
    echo '<div class="blok text-white">
    <a class="btn btn-primary text-white" href="?page=motor_add">Tambah Motor</a>
    </div>';
}
?>
</div>


<div class="card">

<div class="table-responsive text-nowrap">
    <table class="table table-striped">
    <thead>
        <tr>
        <th>Kode Motor</th>
        <th>Nama Motor</th>
        <th>Jenis</th>
        <th>Merk</th>
        <th>Harga</th>
        <th>Stok</th>
        <th>Foto</th>
        <th>Actions</th>
        </tr>
    </thead>
    <tbody class="table-border-bottom-0">
    <?php
$result = mysqli_query($con, "SELECT * FROM tbl_motor");
while ($rm = mysqli_fetch_array($result)) {
    ?>
        <tr>
        <td><span class="badge bg-label-primary me-1"><?=$rm['kd_motor'];?></span></td>
        <td><?=$rm['nm_motor'];?></td>
        <td><?=$rm['jenis'];?></td>
        <td><?=$rm['merk'];?></td>
        <td><?=$rm['harga'];?></td>
        <td><?=$rm['stok'];?></td>
        <td><a href="./assets/img/motor/<?=$rm['foto'];?>" target="_blank">
        <img src="./assets/img/motor/<?=$rm['foto'];?>" alt="" width="50">
        </a></td>
        <td>
<?php
if ($ru['status'] == 'Admin') {
        ?>
<a class="btn btn-warning" href="?page=motor_edit&id_motor=<?=$rm['id_motor']?>"><i class="bx bx-edit-alt me-1"></i></a>
        <a class="btn btn-danger" href="?page=motor_delete&id_motor=<?=$rm['id_motor']?>"><i class="bx bx-trash me-1"></i></a>
        <a class="btn btn-success" href="?page=beli_add&id_motor=<?=$rm['id_motor']?>"><i class="bx bx-cart me-1"></i></a>
<?php
} else {
        ?>
<a class="btn btn-success" href="?page=beli_add&id_motor=<?=$rm['id_motor']?>"><i class="bx bx-cart me-1"></i></a>
<?php
}
    ?>

        </td>
        </tr>
        <?php
}
?>
    </tbody>
    </table>
</div>
</div>
