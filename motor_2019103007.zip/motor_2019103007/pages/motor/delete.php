<?php
$id_motor = $_GET['id_motor'];

$data_foto = mysqli_query($con, "SELECT foto FROM tbl_motor WHERE id_motor='$id_motor'");
$foto_lama = mysqli_fetch_array($data_foto);
unlink("./assets/img/motor/" . $foto_lama['foto']);

// query SQL untuk insert data
$query = "DELETE from tbl_motor where id_motor='$id_motor'";
mysqli_query($con, $query);
// mengalihkan ke halaman index.php
echo "<script language = 'JavaScript'>
              alert('Data berhasil dihapus');
              document.location='index.php?page=motor';
              </script>";
