<?php

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $ekstensi_diperbolehkan = array('png', 'jpg', 'jpeg');
    $foto = $_FILES['foto']['name'];

    $x1 = explode('.', $foto);

    $ekstensi1 = strtolower(end($x1));

    $ukuran_foto = $_FILES['foto']['size'];
    $file_tmp1 = $_FILES['foto']['tmp_name'];

    $angka_acak = rand(1, 9999);

    $foto_baru = $angka_acak . '-' . $foto;

    $folder = "./assets/img/motor/";

    if (in_array($ekstensi1, $ekstensi_diperbolehkan) === true) {
        if ($ukuran_foto < 2044070) {
            move_uploaded_file($file_tmp1, $folder . $foto_baru);

            $query = mysqli_query($con, "INSERT INTO tbl_motor (kd_motor, nm_motor, jenis, merk, harga, stok, foto) values('$_POST[kd_motor]','$_POST[nm_motor]','$_POST[jenis]','$_POST[merk]','$_POST[harga]','$_POST[stok]', '$foto_baru')");

            if ($query) {
                echo "<script language = 'JavaScript'> alert('Data Berhasil Disimpan!'); document.location='index.php?page=motor';</script>";
            } else {
                echo "<script language = 'JavaScript'> alert('Mohon Maaf, Data Gagal Disimpan!')</script>";
            }

        } else {
            echo "<script language = 'JavaScript'> alert('Mohon Maaf, File Foto Yang Anda Upload Terlalu Besar!')</script>";
        }

    } else {
        echo "<script language = 'JavaScript'> alert('Mohon Maaf, Ekstensi File Foto Yang Anda Upload Salah!')</script>";
    }

}

?>

<h4 class="fw-bold py-3 mb-4">
  <span class="text-muted fw-light">Create/</span> Motor
</h4>
<div class="row">
  <div class="col-xl">
    <div class="card mb-4">
      <div class="card-body">
        <form method="post" enctype="multipart/form-data">
          <div class="mb-3">
            <label class="form-label" for="basic-default-fullname"
              >Kode Motor</label
            >
            <input
              type="text"
              name="kd_motor"
              class="form-control"
            />
          </div>
          <div class="mb-3">
            <label class="form-label" for="basic-default-company"
              >Nama Motor</label
            >
            <input
              type="text"
              name="nm_motor"
              class="form-control"
            />
          </div>
          <div class="mb-3">
            <label class="form-label" for="basic-default-email">Jenis</label>
            <div class="input-group input-group-merge">
            <input
              type="text"
              class="form-control phone-mask"
              name="jenis"
            />
            </div>

          </div>
          <div class="mb-3">
          <label for="exampleFormControlSelect1" class="form-label">Merk</label>
          <select class="form-select" id="exampleFormControlSelect1" aria-label="Default select example" name="merk">
            <option selected="">-- Pilih Merk --</option>
            <option value="Honda">Honda</option>
            <option value="Suzuki">Suzuki</option>
            <option value="Yamaha">Yamaha</option>
            <option value="KTM">KTM</option>
            <option value="Kawakasai">Kawakasai</option>
            <option value="Volta">Volta</option>
          </select>
        </div>
          <div class="mb-3">
            <label class="form-label" for="basic-default-phone">Harga</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text">Rp.</span>
              <input type="number" name="harga" class="form-control" placeholder="100" aria-label="Amount (to the nearest rupiah)">
              <span class="input-group-text">.00</span>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label" for="basic-default-phone">Stok</label>
            <input
              type="number"
              class="form-control phone-mask"
              placeholder="XX Unit"
              name="stok"
            />
          </div>
          <div class="mb-3">
            <label for="formFile" class="form-label">Foto</label>
            <input class="form-control" type="file" name="foto">
          </div>

          <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
      </div>
    </div>
  </div>
</div>
