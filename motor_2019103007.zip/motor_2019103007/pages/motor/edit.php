<?php
$id_motor = $_GET['id_motor'];
$sql = mysqli_query($con, "SELECT * FROM tbl_motor WHERE id_motor='$id_motor'");
while ($rm = mysqli_fetch_array($sql)) {
    $id = $rm['id_motor'];
    $kodemotor = $rm['kd_motor'];
    $namamotor = $rm['nm_motor'];
    $jenismotor = $rm['jenis'];
    $merkmotor = $rm['merk'];
    $hargamotor = $rm['harga'];
    $stokmotor = $rm['stok'];
    $fotomotor = $rm['foto'];
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $ekstensi_diperbolehkan = array('png', 'jpg', 'jpeg');
    $foto = $_FILES['foto']['name'];

    $x1 = explode('.', $foto);

    $ekstensi1 = strtolower(end($x1));

    $ukuran_foto = $_FILES['foto']['size'];
    $file_tmp1 = $_FILES['foto']['tmp_name'];

    $angka_acak = rand(1, 9999);

    $foto_baru = $angka_acak . '-' . $foto;

    $folder = "./assets/img/motor/";

    if (in_array($ekstensi1, $ekstensi_diperbolehkan) === true) {
        if ($ukuran_foto < 2044070) {
            $data_foto = mysqli_query($con, "SELECT foto FROM tbl_motor WHERE id_motor='$id_motor'");
            $foto_lama = mysqli_fetch_array($data_foto);
            unlink("./assets/img/motor/" . $foto_lama['foto']);

            move_uploaded_file($file_tmp1, $folder . $foto_baru);

            $query = mysqli_query($con, "UPDATE tbl_motor SET nm_motor = '$_POST[nm_motor]', kd_motor = '$_POST[kd_motor]', jenis = '$_POST[jenis]', merk  = '$_POST[merk]', harga   = '$_POST[harga]', stok = '$_POST[stok]', foto = '$foto_baru' WHERE id_motor='$_POST[id_motor]'");

            if ($query) {
                echo "<script language = 'JavaScript'> confirm('Data Berhasil Diupdate!'); document.location='index.php?page=motor';</script>";
            } else {
                echo "<script language = 'JavaScript'> alert('Mohon Maaf, Foto Gagal Disimpan!')</script>";
            }

        } else {
            echo "<script language = 'JavaScript'> alert('Mohon Maaf, Foto Yang Anda Upload Terlalu Besar!')</script>";
        }

    } else {
        echo "<script language = 'JavaScript'> alert('Mohon Maaf, Ekstensi Foto Yang Anda Upload Salah!')</script>";
    }

}
?>
<h4 class="fw-bold py-3 mb-4">
  <span class="text-muted fw-light">Edit/</span> Motor
</h4>
<div class="row">
  <div class="col-xl">
    <div class="card mb-4">
      <div class="card-body">
      <form method="post" enctype="multipart/form-data">
          <div class="mb-3">
            <label class="form-label" for="basic-default-fullname"
              >Kode Motor</label
            >
            <input
              type="text"
              name="kd_motor"
              class="form-control"
              value="<?=$kodemotor;?>"
            />
            <input
              type="hidden"
              name="id_motor"
              value="<?=$id;?>"
            />
          </div>
          <div class="mb-3">
            <label class="form-label" for="basic-default-company"
              >Nama Motor</label
            >
            <input
              type="text"
              name="nm_motor"
              class="form-control"
              value="<?=$namamotor;?>"
            />
          </div>
          <div class="mb-3">
            <label class="form-label" for="basic-default-email">Jenis</label>
            <div class="input-group input-group-merge">
            <input
              type="text"
              class="form-control phone-mask"
              name="jenis"
              value="<?=$jenismotor;?>"
            />
            </div>

          </div>
          <div class="mb-3">
          <label for="exampleFormControlSelect1" class="form-label">Merk</label>
          <select class="form-select" id="exampleFormControlSelect1" aria-label="Default select example" name="merk">
            <option selected=""><?=$merkmotor;?></option>
            <option value="Honda">Honda</option>
            <option value="Suzuki">Suzuki</option>
            <option value="Yamaha">Yamaha</option>
            <option value="KTM">KTM</option>
            <option value="Kawakasai">Kawakasai</option>
            <option value="Volta">Volta</option>
          </select>
        </div>
        <div class="mb-3">
            <label class="form-label" for="basic-default-phone">Harga</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text">Rp.</span>
              <input type="number" name="harga" class="form-control" placeholder="100" aria-label="Amount (to the nearest rupiah)" value="<?=$hargamotor;?>">
              <span class="input-group-text">.00</span>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label" for="basic-default-phone">Stok</label>
            <input
              type="number"
              class="form-control phone-mask"
              placeholder="XX Unit"
              name="stok"
              value="<?=$stokmotor;?>"
            />
          </div>
          <div class="mb-3">
            <label for="formFile" class="form-label">Foto</label>
            <input class="form-control" type="file" name="foto" value="<?=$fotomotor;?>">
          </div>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
      </div>
    </div>
  </div>
</div>
