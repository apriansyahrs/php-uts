<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $user = $_POST['username'];
    $pass = $_POST['password'];
    $sqlu = mysqli_query($con, "SELECT * FROM tbl_user WHERE username='$user' AND password='$pass'");
    $row = mysqli_num_rows($sqlu);

    if ($row > 0) {
        $ru = mysqli_fetch_assoc($sqlu);
        session_start();
        $_SESSION['nama'] = $ru['username'];

        echo "<script language = 'JavaScript'>
                  confirm('Login Berhasil!');
                  document.location='index.php';
                  </script>";
    } else {
        echo "<script language = 'JavaScript'>
              alert('Login gagal, silahkan coba lagi');
              document.location='index.php';
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="shortcut icon"
      href="assets/images/favicon.svg"
      type="image/x-icon"
    />
    <title>Sign In | PT. Cahaya Abadi</title>

    <!-- ========== All CSS files linkup ========= -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/lineicons.css" />
    <link rel="stylesheet" href="assets/css/materialdesignicons.min.css" />
    <link rel="stylesheet" href="assets/css/fullcalendar.css" />
    <link rel="stylesheet" href="assets/css/main.css" />
  </head>
  <body>
    <div class="container">
      <div class="row g-0 auth-row mt-5">
        <div class="col-lg-6">
          <div class="auth-cover-wrapper bg-primary-100">
            <div class="auth-cover">
              <div class="title text-center">
                <h1 class="text-primary mb-10">Welcome Back</h1>
                <p class="text-medium">
                  Sign in to your Existing account to continue
                </p>
              </div>
              <div class="cover-image">
                <img src="assets/images/auth/signin-image.svg" alt="" />
              </div>
              <div class="shape-image">
                <img src="assets/images/auth/shape.svg" alt="" />
              </div>
            </div>
          </div>
        </div>
        <!-- end col -->
        <div class="col-lg-6">
          <div class="signin-wrapper">
            <div class="form-wrapper">
              <h6 class="mb-15">Sign In Form</h6>
              <p class="text-sm mb-25">
                Start creating the best possible user experience for you
                customers.
              </p>
              <form action="#" action="" method="POST">
                <div class="row">
                  <div class="col-12">
                    <div class="input-style-1">
                      <label>Username</label>
                      <input
                        type="text"
                        name="username"
                        placeholder="Username"
                      />
                    </div>
                  </div>
                  <!-- end col -->
                  <div class="col-12">
                    <div class="input-style-1">
                      <label>Password</label>
                      <input
                        type="password"
                        name="password"
                        placeholder="Password"
                      />
                    </div>
                  </div>

                  <!-- end col -->
                  <div class="col-12">
                    <div
                      class="button-group d-flex justify-content-center flex-wrap"
                    >
                      <button
                        class="main-btn primary-btn btn-hover w-100 text-center"
                        type="submit"
                      >
                        Sign In
                      </button>
                    </div>
                  </div>
                </div>
                <!-- end row -->
              </form>
              <div class="singin-option pt-40">
                <p class="text-sm text-medium text-dark text-center">
                  Don’t have any account yet?
                  <a href="./signup.php">Create an account</a>
                </p>
              </div>
            </div>
          </div>
        </div>
        <!-- end col -->
      </div>
      <!-- end row -->
    </div>
    <!-- ========= All Javascript files linkup ======== -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/Chart.min.js"></script>
    <script src="assets/js/dynamic-pie-chart.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/fullcalendar.js"></script>
    <script src="assets/js/jvectormap.min.js"></script>
    <script src="assets/js/world-merc.js"></script>
    <script src="assets/js/polyfill.js"></script>
    <script src="assets/js/main.js"></script>
  </body>
</html>
