<!-- ========== title-wrapper start ========== -->
<div class="title-wrapper pt-30">
<div class="row align-items-center">
    <div class="col-md-6">
    <div class="title mb-30">
        <h2>Data Motor</h2>
    </div>
    </div>
    <!-- end col -->
    <div class="col-md-6">
    <div class="breadcrumb-wrapper mb-30">
    <?php
if ($ru['status'] == 'Admin') {
    echo '<div class="blok text-white">
    <a class="btn btn-primary text-white" href="?page=transaksi_add">Tambah Transaksi</a>
    </div>';
}
?>
    </div>
    </div>
    <!-- end col -->
</div>
<!-- end row -->
</div>
<!-- ========== title-wrapper end ========== -->


<div class="card-style mb-30">

<div class="table-responsive text-nowrap">
    <table class="table">
    <thead>
        <tr>
        <th>Tanggal Beli</th>
        <th>Nama Beli</th>
        <th>Kode Motor</th>
        <th>Nama Motor</th>
        <th>Harga</th>
        <th>Jumlah Unit</th>
        <th>Diskon</th>
        <th>Pajak</th>
        <th>Total</th>
<?php
if ($ru['status'] == 'Admin') {
    echo '<th>Actions</th>';
}
?>
        </tr>
    </thead>
    <tbody class="table-border-bottom-0">
    <?php
if ($ru['status'] == 'Admin') {
    $result = mysqli_query($con, "SELECT * FROM tbl_beli");
} else {
    $result = mysqli_query($con, "SELECT * FROM tbl_beli WHERE nm_pembeli = '$ru[nm_user]'");

}

while ($rm = mysqli_fetch_array($result)) {
    ?>
        <tr>
        <td><?=$rm['tgl_pembeli'];?></td>
        <td><?=$rm['nm_pembeli'];?></td>
        <td><span class="badge bg-label-primary me-1"><?=$rm['kd_motor'];?></span></td>
        <td><?=$rm['nm_motor'];?></td>
        <td><?=rupiah($rm['harga']);?></td>
        <td><?=$rm['jumlah'];?></td>
        <td><?=rupiah($rm['diskon']);?></td>
        <td><?=rupiah($rm['pajak']);?></td>
        <td><?=rupiah($rm['total']);?></td>
        <?php
if ($ru['status'] == 'Admin') {
        ?>
        <td>
        <a class="btn btn-warning" href="?page=transaksi_edit&id_beli=<?=$rm['id_beli']?>">Edit</a>
        <a class="btn btn-danger" href="?page=transaksi_delete&id_beli=<?=$rm['id_beli']?>">Hapus</a>
        </td>
            <?php
}
    ?>

        </tr>
        <?php
}
?>
    </tbody>
    </table>
</div>
</div>
