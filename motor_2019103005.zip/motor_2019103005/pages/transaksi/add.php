<?php

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $sqlm = mysqli_query($con, "SELECT * FROM tbl_motor WHERE id_motor = '$_POST[id_motor];'");
    $rm = mysqli_fetch_array($sqlm);
    $kodemotor = $rm['kd_motor'];
    $namamotor = $rm['nm_motor'];
    $hargamotor = $rm['harga'];

    $jumlah = $_POST['jumlah'];

    $diskon = 0.025 * ($jumlah * $hargamotor);
    $pajak = 0.1 * ($jumlah * $hargamotor);
    $total = $diskon - $pajak + ($jumlah * $hargamotor);

    $query = mysqli_query($con, "INSERT INTO tbl_beli(tgl_pembeli, nm_pembeli, kd_motor, nm_motor, harga, jumlah, diskon, pajak, total) value('$_POST[tgl_pembeli]','$_POST[nm_pembeli]','$kodemotor','$namamotor', '$hargamotor', '$jumlah', '$diskon', '$pajak', '$total')");

    echo "<script language = 'JavaScript'>
          alert('Data berhasil ditambah');
          document.location='index.php?page=transaksi';
        </script>";
}

?>

<!-- ========== title-wrapper start ========== -->
<div class="title-wrapper pt-30">
<div class="row align-items-center">
    <div class="col-md-6">
    <div class="title mb-30">
        <h2>Beli Motor</h2>
    </div>
    </div>
</div>
<!-- end row -->
</div>
<!-- ========== title-wrapper end ========== -->
<div class="row">
  <div class="col-xl">
    <div class="card mb-4">
      <div class="card-body">
        <form method="post" enctype="multipart/form-data">
          <div class="mb-3">
            <label class="form-label" for="basic-default-fullname"
              >Tanggal Pembeli</label
            >
            <input
              type="date"
              name="tgl_pembeli"
              class="form-control"
            />
          </div>
          <div class="mb-3">
            <label class="form-label" for="basic-default-company"
              >Nama Pembeli</label
            >
            <input
              type="text"
              name="nm_pembeli"
              class="form-control"
              <?php
if ($ru['status'] == 'Customer') {
    echo "value='$ru[nm_user]'";
    echo 'readonly';
}
?>

            />
          </div>

          <div class="form-group mb-3">
            <label for="exampleFormControlSelect1">Motor</label>
            <select class="form-control" id="exampleFormControlSelect1" name="id_motor">
            <?php
if (isset($_GET['id_motor'])) {
    $sql = mysqli_query($con, "SELECT * FROM tbl_motor WHERE id_motor = '$_GET[id_motor];'");
    $r = mysqli_fetch_array($sql);
    ?>
<option value="<?=$r['id_motor'];?>"><?=$r['kd_motor'] . " / " . $r['nm_motor'] . " / " . rupiah($r['harga']);?></option>
<?php
} else {
    ?>
<option selected="">-- Pilih Kode Motor --</option>
              <?php
$result = mysqli_query($con, "SELECT * FROM tbl_motor");
    while ($rm = mysqli_fetch_array($result)) {
        ?>
              <option value="<?=$rm['id_motor'];?>"><?=$rm['kd_motor'] . " / " . $rm['nm_motor'] . " / " . rupiah($rm['harga']);?></option>
              <?php
}
    ?>
  <?php
}
?>
            </select>
          </div>


          <div class="mb-3">
            <label class="form-label" for="basic-default-email">Jumlah</label>
            <div class="input-group input-group-merge">
            <input
              type="text"
              class="form-control phone-mask"
              name="jumlah"
            />
            </div>
          </div>

          <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
      </div>
    </div>
  </div>
</div>
