<?php
$id_beli = $_GET['id_beli'];

// query SQL untuk insert data
$query = "DELETE from tbl_beli where id_beli='$id_beli'";
mysqli_query($con, $query);
// mengalihkan ke halaman index.php
echo "<script language = 'JavaScript'>
              alert('Data berhasil dihapus');
              document.location='index.php?page=transaksi';
              </script>";
