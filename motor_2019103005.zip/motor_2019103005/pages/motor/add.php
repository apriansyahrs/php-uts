<?php

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $ekstensi_diperbolehkan = array('png', 'jpg', 'jpeg');
    $foto = $_FILES['foto']['name'];

    $x1 = explode('.', $foto);

    $ekstensi1 = strtolower(end($x1));

    $ukuran_foto = $_FILES['foto']['size'];
    $file_tmp1 = $_FILES['foto']['tmp_name'];

    $angka_acak = rand(1, 9999);

    $foto_baru = $angka_acak . '-' . $foto;

    $folder = "./assets/images/motor/";

    if (in_array($ekstensi1, $ekstensi_diperbolehkan) === true) {
        if ($ukuran_foto < 2044070) {
            move_uploaded_file($file_tmp1, $folder . $foto_baru);

            $query = mysqli_query($con, "INSERT INTO tbl_motor (kd_motor, nm_motor, jenis, merk, harga, stok, foto) values('$_POST[kd_motor]','$_POST[nm_motor]','$_POST[jenis]','$_POST[merk]','$_POST[harga]','$_POST[stok]', '$foto_baru')");

            if ($query) {
                echo "<script language = 'JavaScript'> alert('Data Berhasil Disimpan!'); document.location='index.php';</script>";
            } else {
                echo "<script language = 'JavaScript'> alert('Mohon Maaf, Data Gagal Disimpan!')</script>";
            }

        } else {
            echo "<script language = 'JavaScript'> alert('Mohon Maaf, File Foto Yang Anda Upload Terlalu Besar!')</script>";
        }

    } else {
        echo "<script language = 'JavaScript'> alert('Mohon Maaf, Ekstensi File Foto Yang Anda Upload Salah!')</script>";
    }

}

?>

<!-- ========== title-wrapper start ========== -->
<div class="title-wrapper pt-30">
<div class="row align-items-center">
    <div class="col-md-6">
    <div class="title mb-30">
        <h2>Tambah Motor</h2>
    </div>
    </div>
</div>
<!-- end row -->
</div>
<!-- ========== title-wrapper end ========== -->
<div class="row">
  <div class="col-xl">
    <div class="card mb-4">
      <div class="card-body">
        <form method="post" enctype="multipart/form-data">
          <div class="mb-3">
            <label class="form-label" for="basic-default-fullname"
              >Kode Motor</label
            >
            <input
              type="text"
              name="kd_motor"
              class="form-control"
            />
          </div>
          <div class="mb-3">
            <label class="form-label" for="basic-default-company"
              >Nama Motor</label
            >
            <input
              type="text"
              name="nm_motor"
              class="form-control"
            />
          </div>
          <div class="form-group mb-3">
            <label for="exampleFormControlSelect1">Jenis</label>
            <select class="form-control" id="exampleFormControlSelect1" name="jenis">
            <option selected="">-- Pilih Jenis --</option>
              <option>Matic</option>
              <option>Kopling</option>
              <option>Gigi</option>
            </select>
          </div>

          <div class="form-group mb-3">
            <label for="exampleFormControlSelect1">Merk</label>
            <select class="form-control" id="exampleFormControlSelect1" name="merk">
              <option selected="">-- Pilih Merk --</option>
              <option value="Honda">Honda</option>
              <option value="Suzuki">Suzuki</option>
              <option value="Yamaha">Yamaha</option>
              <option value="KTM">KTM</option>
              <option value="Kawakasai">Kawakasai</option>
              <option value="Volta">Volta</option>
            </select>
          </div>


          <div class="mb-3">
          <label class="form-label" for="basic-default-phone">Harga</label>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text">$</span>
              </div>
              <input type="number" name="harga" class="form-control" placeholder="100" aria-label="Amount (to the nearest rupiah)">
              <div class="input-group-append">
                <span class="input-group-text">.00</span>
              </div>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label" for="basic-default-phone">Stok</label>
            <input
              type="number"
              class="form-control phone-mask"
              placeholder="XX Unit"
              name="stok"
            />
          </div>
          <div class="mb-3">
            <label for="formFile" class="form-label">Foto</label>
            <input class="form-control" type="file" name="foto">
          </div>

          <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
      </div>
    </div>
  </div>
</div>
