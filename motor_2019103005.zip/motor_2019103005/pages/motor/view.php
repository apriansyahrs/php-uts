<!-- ========== title-wrapper start ========== -->
<div class="title-wrapper pt-30">
<div class="row align-items-center">
    <div class="col-md-6">
    <div class="title mb-30">
        <h2>Data Motor</h2>
    </div>
    </div>
    <!-- end col -->
    <div class="col-md-6">
    <div class="breadcrumb-wrapper mb-30">
    <?php
if ($ru['status'] == 'Admin') {
    echo '<div class="blok text-white">
    <a class="btn btn-primary text-white" href="?page=motor_add">Tambah Motor</a>
    </div>';
}
?>
    </div>
    </div>
    <!-- end col -->
</div>
<!-- end row -->
</div>
<!-- ========== title-wrapper end ========== -->
<div class="row">
<div class="col-xl-3 col-lg-4 col-sm-6">
    <div class="icon-card mb-30">
    <div class="icon purple">
        <i class="lni lni-cart-full"></i>
    </div>
    <div class="content">
        <h6 class="mb-10">New Orders</h6>
        <h3 class="text-bold mb-10">34567</h3>
        <p class="text-sm text-success">
        <i class="lni lni-arrow-up"></i> +2.00%
        <span class="text-gray">(30 days)</span>
        </p>
    </div>
    </div>
    <!-- End Icon Cart -->
</div>
<!-- End Col -->
<div class="col-xl-3 col-lg-4 col-sm-6">
    <div class="icon-card mb-30">
    <div class="icon success">
        <i class="lni lni-dollar"></i>
    </div>
    <div class="content">
        <h6 class="mb-10">Total Income</h6>
        <h3 class="text-bold mb-10">$74,567</h3>
        <p class="text-sm text-success">
        <i class="lni lni-arrow-up"></i> +5.45%
        <span class="text-gray">Increased</span>
        </p>
    </div>
    </div>
    <!-- End Icon Cart -->
</div>
<!-- End Col -->
<div class="col-xl-3 col-lg-4 col-sm-6">
    <div class="icon-card mb-30">
    <div class="icon primary">
        <i class="lni lni-credit-cards"></i>
    </div>
    <div class="content">
        <h6 class="mb-10">Total Expense</h6>
        <h3 class="text-bold mb-10">$24,567</h3>
        <p class="text-sm text-danger">
        <i class="lni lni-arrow-down"></i> -2.00%
        <span class="text-gray">Expense</span>
        </p>
    </div>
    </div>
    <!-- End Icon Cart -->
</div>
<!-- End Col -->
<div class="col-xl-3 col-lg-4 col-sm-6">
    <div class="icon-card mb-30">
    <div class="icon orange">
        <i class="lni lni-user"></i>
    </div>
    <div class="content">
        <h6 class="mb-10">New User</h6>
        <h3 class="text-bold mb-10">34567</h3>
        <p class="text-sm text-danger">
        <i class="lni lni-arrow-down"></i> -25.00%
        <span class="text-gray"> Earning</span>
        </p>
    </div>
    </div>
    <!-- End Icon Cart -->
</div>
<!-- End Col -->
</div>

<div class="card-style mb-30">
<div class="table-wrapper table-responsive">
    <table class="table">
    <thead>
        <tr>
        <th>Kode Motor</th>
        <th>Nama Motor</th>
        <th>Jenis</th>
        <th>Merk</th>
        <th>Harga</th>
        <th>Stok</th>
        <th>Foto</th>
        <th>Actions</th>
        </tr>
    </thead>
    <tbody class="table-border-bottom-0">
    <?php
$result = mysqli_query($con, "SELECT * FROM tbl_motor");
while ($rm = mysqli_fetch_array($result)) {
    ?>
        <tr>
        <td><?=$rm['kd_motor'];?></td>
        <td><?=$rm['nm_motor'];?></td>
        <td><?=$rm['jenis'];?></td>
        <td><?=$rm['merk'];?></td>
        <td><?=$rm['harga'];?></td>
        <td><?=$rm['stok'];?></td>
        <td><a href="./assets/images/motor/<?=$rm['foto'];?>" target="_blank">
        <img src="./assets/images/motor/<?=$rm['foto'];?>" alt="" width="50">
        </a></td>
        <td>
<?php
if ($ru['status'] == 'Admin') {
        ?>
<a class="btn btn-success" href="?page=transaksi_add&id_motor=<?=$rm['id_motor']?>">Beli</a>
<a class="btn btn-warning" href="?page=motor_edit&id_motor=<?=$rm['id_motor']?>">Edit</a>
        <a class="btn btn-danger" href="?page=motor_delete&id_motor=<?=$rm['id_motor']?>">Hapus</a>
<?php
} else {
        ?>
<a class="btn btn-success" href="?page=transaksi_add&id_motor=<?=$rm['id_motor']?>">Beli</a>
<?php
}
    ?>

        </td>
        </tr>
        <?php
}
?>
    </tbody>
    </table>
</div>
</div>
